#include "type.h"
#include "stdio.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "proto.h"
#define H 25
#define L 14
//�����Ҫ�ж�����һ���Ƿ���ص�����������ʾ�Ѿ�����


int array[H][L];    //���з�����ϵĵط�
//28�б���
int to_change[7][4][4][2] = { {{{0,0},{0,0},{0,0},{0,0}},{{0,0},{0,0},{0,0},{0,0}},{{0,0},{0,0},{0,0},{0,0}},{{0,0},{0,0},{0,0},{0,0}}},
              {{{2,1},{1,0},{0,1},{-1,0}},{{-2,-1},{-1,0},{0,-1},{1,0}},{{2,1},{1,0},{0,1},{-1,0}},{{-2,-1},{-1,0},{0,-1},{1,0}}},
              {{{1,2},{0,1},{1,0},{0,-1}},{{-1,-2},{0,-1},{-1,0},{0,1}},{{1,2},{0,1},{1,0},{0,-1}},{{-1,-2},{0,-1},{-1,0},{0,1}}},
              {{{-1,2},{-2,1},{-1,0},{0,-1}},{{2,0},{1,1},{0,0},{-1,-1}},{{0,-1},{1,0},{0,1},{-1,2}},{{-1,-1},{0,-2},{1,-1},{2,0}}},
              {{{1,0},{0,-1},{-1,0},{-2,1}},{{0,-2},{-1,-1},{0,0},{1,1}},{{-2,1},{-1,2},{0,1},{1,0}},{{1,1},{2,0},{1,-1},{0,-2}}},
              {{{-3,2},{-2,-1},{-1,0},{0,1}},{{3,-2},{2,1},{1,0},{0,-1}},{{-3,2},{-2,-1},{-1,0},{0,1}},{{3,-2},{2,1},{1,0},{0,-1}}},
              {{{0,1},{-2,1},{-1,0},{0,-1}},{{1,-1},{1,1},{0,0},{-1,-1}},{{-1,0},{1,0},{0,1},{-1,2}},{{0,0},{0,-2},{1,-1},{2,0}}} };
//7��ͼ��
int block[7][4][2] = { {{2,6},{2,7},{3,6},{3,7}},
                    {{1,7},{2,7},{2,6},{3,6}},
                    {{1,6},{2,6},{2,7},{3,7}},
                    {{2,6},{3,6},{3,7},{3,8}},
                    {{2,8},{3,8},{3,7},{3,6}},
                    {{3,5},{3,8},{3,7},{3,6}},
                    {{2,7},{3,6},{3,7},{3,8}} };
int randnum=500;//α�����
int picture;//ͼ�ε����
int now;  //��ǰͼ�εı仯��
int graph[4][2];//ͼ�ε�����
char control;
char buff[1] = { 0 };
int start;

void Change();
void Move(char M);  //���������AD�ж������ƶ�
int See();         //�ж��Ƿ񵽵�
void New();         //����
void Go();          //������һ��
void Begin();       //һ��ֵ��ʼ��
int Elimination(); //�������е���ȥ
void Cout();        //�������
void tetris(fd_stdin)
{

    Begin();
    Cout();
    while (1) {

        //if (GetTickCount() - start >= 500) {

            //start = GetTickCount();
        randnum++;
            if (!See()) Go();
            else {
                if (Elimination())break;
                New();
            }
            clear();
            Cout();
        //}


        //if (_kbhit()) {
          
            
            //control = getch();
            if (read(fd_stdin, buff, 1))
            {
                control = buff[0];
                if (control == 'q' || control == 'Q') break;
                else if (control == 'W' || control == 'w')Change();
                else if ((control == 's' || control == 'S')&& !See()) Go();
                else Move(control);
                clear();
                Cout();
            }
           
        //}
    }
    //��Ȼ������ĸ߶�Ϊ25������ʾʱֻ��ʾ��20��
}

void Change()
{
    randnum--;
    for (int i = 0; i < 4; i++)
        array[graph[i][0]][graph[i][1]] = 0;
    now = (now + 1) % 4;
    for (int i = 0; i < 4; i++) {
        graph[i][0] += to_change[picture][now][i][0];
        graph[i][1] += to_change[picture][now][i][1];
    }
    for (int i = 0; i < 4; i++) {
        if (graph[i][1] < 0) {
            int temp = 0 - graph[i][1];
            for (int j = 0; j < 4; j++)graph[j][1] += temp;
        }
        if (graph[i][1] > L - 1) {
            int temp = graph[i][1] - (L - 1);
            for (int j = 0; j < 4; j++)graph[j][1] -= temp;
        }
    }
    for (int i = 0; i < 4; i++)
        array[graph[i][0]][graph[i][1]] = 2;
}
void Move(char M)
{
    randnum++;
    for (int i = 0; i < 4; i++)
        array[graph[i][0]][graph[i][1]] = 0;

    if ((M == 'a' || M == 'A') && graph[0][1] && graph[1][1] && graph[2][1] && graph[3][1])
        if (array[graph[0][0]][graph[0][1] - 1] != 1 && array[graph[1][0]][graph[1][1] - 1] != 1 && array[graph[2][0]][graph[2][1] - 1] != 1 && array[graph[3][0]][graph[3][1] - 1] != 1) {
            graph[0][1]--;
            graph[1][1]--;
            graph[2][1]--;
            graph[3][1]--;
        }
    if ((M == 'd' || M == 'D') && graph[0][1] < L - 1 && graph[1][1] < L - 1 && graph[2][1] < L - 1 && graph[3][1] < L - 1)
        if (array[graph[0][0]][graph[0][1] + 1] != 1 && array[graph[1][0]][graph[1][1] + 1] != 1 && array[graph[2][0]][graph[2][1] + 1] != 1 && array[graph[3][0]][graph[3][1] + 1] != 1) {
            graph[0][1]++;
            graph[1][1]++;
            graph[2][1]++;
            graph[3][1]++;
        }
    for (int i = 0; i < 4; i++)
        array[graph[i][0]][graph[i][1]] = 2;
}
int See()
{
    for (int i = 0; i < 4; i++)
        if (graph[i][0] + 1 == H)return 1;
    for (int i = 0; i < 4; i++)
        if (array[graph[i][0] + 1][graph[i][1]] == 1)return 1;
    return 0;
}
void New()
{
    picture = randnum % 7;
    now = -1;
    for (int i = 0; i < 4; i++) {
        graph[i][0] = block[picture][i][0];
        graph[i][1] = block[picture][i][1];
        array[graph[i][0]][graph[i][1]] = 2;
    }
}
void Go()
{
    for (int i = 0; i < 4; i++) {
        array[graph[i][0]][graph[i][1]] = 0;
        graph[i][0]++;
    }
    for (int i = 0; i < 4; i++)
        array[graph[i][0]][graph[i][1]] = 2;
}
void Begin()
{
    //start = GetTickCount();//��ʼ��ʱ��
    for (int i = 0; i < H; i++)
        for (int j = 0; j < L; j++)
            array[i][j] = 0;
    picture = randnum % 7;
    now = -1;
    for (int i = 0; i < 4; i++) {
        graph[i][0] = block[picture][i][0];
        graph[i][1] = block[picture][i][1];
        array[graph[i][0]][graph[i][1]] = 2;
    }
}

int Elimination()
{
    for (int i = 0; i < 4; i++) {
        array[graph[i][0]][graph[i][1]] = 1;
        if (graph[i][0] < 4)return 1;
    }
    for (int i = H - 1; i >= 0; ) {
        int j;
        for (j = 0; j < L; j++)
            if (array[i][j] != 1)break;
        if (j == L) {
            for (int k = i; k > 0; k--)
                for (int l = 0; l < L; l++)
                    array[k][l] = array[k - 1][l];
        }
        else i--;
    }
    return 0;
}
void Cout()
{
    for (int i = 5; i < H; i++) {
        for (int j = 0; j < L; j++) {
            if (array[i][j] == 0)printf(".");
            else if (array[i][j] == 1) {
                printf("#");

            }
            else printf("o");
        }
        printf("\n");
    }
}