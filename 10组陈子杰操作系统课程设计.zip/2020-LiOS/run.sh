make clean
make image
bochs -f bochsrc
